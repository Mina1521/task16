module.exports = {
  experimental: {
    outputStandalone: true,
  },
};
